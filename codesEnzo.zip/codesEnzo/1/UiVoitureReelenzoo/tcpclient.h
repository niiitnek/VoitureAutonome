#ifndef TCPCLIENT_H
#define TCPCLIENT_H
#include <QTcpSocket>

#include <QDataStream>
#include <QTimer>


class TCPclient :public QObject

{
    Q_OBJECT
public:
    TCPclient(QString _Host, int _port);
    void sendDatas(QString datas);
    void onReadyRead();

private:
    QString Host;
    QTcpSocket clientSocket;
    int port;
    QTimer reconnexion;     // MODIF : refait la connexion si elle est perdue
    void connectTCP();
    void ReconnectConnectOrWait();
signals:
    void newDatas(QString datas);

};

#endif // TCPCLIENT_H