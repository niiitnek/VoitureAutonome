#include "capteurtension.h"

CapteurTension::CapteurTension(const TedsBatterie &_teds)
    : teds(_teds)
    , i2c(I2C1, _teds.adresseI2C)     // MODIF : adresse lue dans la TEDS (0x4D d'après le schéma)
    , nivTension(0)
//, serverBatterie(????)
{
}

float CapteurTension::getValue()
{
    unsigned char data[2];

    // MODIF : l'ancien appel readRegisters(0x49, data, 2) demandait 0x49 = 73 octets
    // (le 1er paramètre est le NOMBRE d'octets) dans un tableau de 2 : débordement mémoire.
    // Le MCP3021 n'a pas de registre : on lit simplement 2 octets.
    if (!i2c.transfert(nullptr, 0, data, 2)) {
        qDebug() << "Erreur lecture MCP3021";
        return -1;
    }

    valeurBrute = ((data[0] << 8) | data[1]) >> 2;     // 10 bits utiles
    nivTension = teds.convertir(valeurBrute);           // MODIF : conversion donnée par la TEDS

    qDebug() << "Tension batterie:" << nivTension << "V";
    return nivTension;      // MODIF : la tension de la batterie (avant : celle de l'entrée de l'ADC)
}

int CapteurTension::getValeurBrute() const
{
    return valeurBrute;
}

void CapteurTension::tension()
{
    getValue();
    QString datatension = QString::number(nivTension);
    //Batterie.tension(datatension);
}
