#ifndef CAPTEURTENSION_H
#define CAPTEURTENSION_H

#include "qi2cdevice.h"
#include "tedsbatterie.h"     // MODIF : la TEDS donne l'adresse et la conversion
//#include "tcpserver.h"

#include <QDebug>
#include <QString>

class CapteurTension
{
public:
    // MODIF : la TEDS est passée au constructeur (valeurs par défaut sinon)
    explicit CapteurTension(const TedsBatterie &_teds = TedsBatterie());
    float getValue();              // tension de la BATTERIE en V, -1 si erreur de lecture
    int getValeurBrute() const;    // AJOUT : dernière valeur brute de l'ADC (0..1023), -1 si aucune
    void tension();

    // TcpServer Batterie;

private:
    TedsBatterie teds;             // MODIF : déclarée AVANT i2c, qui utilise son adresse
    QI2cDevice i2c;
    float nivTension;
    int valeurBrute = -1;
};

#endif // CAPTEURTENSION_H
