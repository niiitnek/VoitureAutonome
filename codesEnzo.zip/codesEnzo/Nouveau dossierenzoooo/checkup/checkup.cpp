#include "checkup.h"
#include "qi2cdevice.h"
#include "capteurtension.h"
#include "rplidar.h"
#include "tcpserveur.h"
#include "tcpclient.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QNetworkInterface>
#include <QTcpServer>
#include <QStringList>
#include <algorithm>

// ============================================================ ResultatTest

QString ResultatTest::ligne() const
{
    QString etiquette = (statut == Statut::OK)     ? "[OK]"
                      : (statut == Statut::ALERTE) ? "[ALERTE]"
                                                   : "[ERREUR]";
    return QString("%1 %2 : %3").arg(etiquette, -9).arg(nom, -15).arg(detail);
}

// ============================================================ Checkup

Checkup::Checkup(QObject *parent)
    : QObject(parent)
{
}

QList<ResultatTest> Checkup::lancer()
{
    resultats.clear();
    busExplore = false;

    ajouter(testBusI2C());
    ajouter(testBatterie());
    ajouter(testLidar360());
    ajouter(testTfMini(adresseTfGauche, "gauche"));
    ajouter(testTfMini(adresseTfDroite, "droit"));
    if (adresseTfGauche == adresseTfDroite) {
        ajouter({"TFmini", Statut::ALERTE,
                 "les deux capteurs ont la même adresse " + hex(adresseTfGauche) + " : changer celle d'un des deux"});
    }
    ajouter(testReseau());
    ajouter(testTcp());
    return resultats;
}

void Checkup::ajouter(const ResultatTest &r)
{
    resultats << r;
    emit nouveauResultat(r.ligne());
}

// ------------------------------------------------------------ bus I2C

ResultatTest Checkup::testBusI2C()
{
    ResultatTest r{"Bus I2C"};
    adressesI2C.clear();

    try {
        QI2cDevice essai(I2C1, 0x08);
    } catch (const std::exception &) {
        r.statut = Statut::ERREUR;
        r.detail = "/dev/i2c-1 inaccessible (I2C désactivé dans raspi-config, ou droits insuffisants)";
        return r;
    }

    // On interroge chaque adresse possible : celles qui répondent ont un composant
    for (int adresse = 0x08; adresse <= 0x77; adresse++) {
        QI2cDevice composant(I2C1, adresse);
        unsigned char octet;
        if (composant.transfert(nullptr, 0, &octet, 1)) adressesI2C << adresse;
    }
    busExplore = true;

    QStringList trouves;
    for (int a : adressesI2C) {
        QString nom = (a == 0x58)                 ? "MD04"
                    : (a >= 0x48 && a <= 0x4F)    ? "MCP3021"
                    : (a == adresseTfGauche)      ? "TFmini gauche"
                    : (a == adresseTfDroite)      ? "TFmini droit"
                                                  : "inconnu";
        trouves << hex(a) + " " + nom;
    }

    if (adressesI2C.isEmpty()) {
        r.statut = Statut::ERREUR;
        r.detail = "aucun composant ne répond (carte d'extension alimentée ? câble ?)";
    } else if (!adressesI2C.contains(0x58)) {
        r.statut = Statut::ALERTE;
        r.detail = trouves.join(", ") + " ; driver moteur MD04 absent (0x58)";
    } else {
        r.detail = trouves.join(", ");
    }
    return r;
}

// ------------------------------------------------------------ batterie

ResultatTest Checkup::testBatterie()
{
    TedsBatterie t = teds;
    QString remarque;

    // Si l'adresse de la TEDS ne répond pas, on cherche un MCP3021 ailleurs sur le bus
    if (busExplore && !adressesI2C.contains(t.adresseI2C)) {
        for (int a = 0x48; a <= 0x4F; a++) {
            if (adressesI2C.contains(a)) {
                remarque = "MCP3021 trouvé en " + hex(a) + " et non en " + hex(t.adresseI2C)
                         + " : corriger la TEDS. ";
                t.adresseI2C = a;
                break;
            }
        }
    }

    try {
        CapteurTension capteur(t);

        // Moyenne de 5 lectures
        double somme = 0;
        int nbLectures = 0;
        for (int i = 0; i < 5; i++) {
            float v = capteur.getValue();
            if (v >= 0) { somme += v; nbLectures++; }
            attendre(20);
        }
        if (nbLectures == 0) {
            return {"Batterie", Statut::ERREUR,
                    remarque + "le MCP3021 ne répond pas en " + hex(t.adresseI2C), true};
        }

        ResultatTest r = evaluerBatterie(somme / nbLectures, capteur.getValeurBrute(), t);
        if (!remarque.isEmpty()) {
            r.detail = remarque + r.detail;
            if (r.statut == Statut::OK) r.statut = Statut::ALERTE;
        }
        return r;
    } catch (const std::exception &) {
        return {"Batterie", Statut::ERREUR, "bus I2C inaccessible", true};
    }
}

ResultatTest Checkup::evaluerBatterie(double tension, int valeurBrute, const TedsBatterie &t)
{
    ResultatTest r{"Batterie"};
    r.critique = true;
    const int maxi = (1 << t.resolutionBits) - 1;
    QString mesure = QString("%1 V (%2 %), brute %3")
                         .arg(tension, 0, 'f', 2).arg(t.pourcentage(tension)).arg(valeurBrute);

    if (valeurBrute >= maxi) {
        r.statut = Statut::ERREUR;
        r.detail = QString("ADC saturé : tension > %1 V, ou vref / rapportPont faux dans la TEDS")
                       .arg(t.tensionMaxMesurable(), 0, 'f', 2);
    } else if (tension < 1.0) {
        r.statut = Statut::ERREUR;
        r.detail = mesure + " : batterie débranchée, interrupteur coupé ou pont diviseur ?";
    } else if (tension < t.tensionVide) {
        r.statut = Statut::ERREUR;
        r.detail = mesure + " : batterie vide, recharger avant de rouler";
    } else if (tension < t.tensionAlerte) {
        r.statut = Statut::ALERTE;
        r.detail = mesure + " : batterie faible, recharger bientôt";
    } else if (tension > t.tensionPleine + 0.3) {
        r.statut = Statut::ALERTE;
        r.detail = mesure + " : tension trop haute, vérifier vref et rapportPont dans la TEDS";
    } else {
        r.detail = mesure;
    }
    return r;
}

// ------------------------------------------------------------ lidar 360

ResultatTest Checkup::testLidar360()
{
    std::array<int, 360> distances{};
    RpLidar lidar(distances, portSerieLidar);

    if (!lidar.estConnecte()) {
        return {"Lidar 360", Statut::ERREUR,
                "pas de réponse sur " + portSerieLidar
                    + " (câble USB ? alimentation ? programme voiture déjà lancé ?)", true};
    }
    if (lidar.getSante() == 2) {
        return {"Lidar 360", Statut::ERREUR,
                "le lidar signale une panne (code " + hex(lidar.getCodeErreur()) + ")", true};
    }

    attendre(1500);   // le moteur prend sa vitesse

    // Plusieurs tours : on garde le meilleur
    int meilleur = -1;
    std::array<int, 360> meilleurTour{};
    for (int essai = 0; essai < 5; essai++) {
        if (lidar.update() && lidar.getNbMesures() > meilleur) {
            meilleur = lidar.getNbMesures();
            meilleurTour = distances;
        }
    }
    if (meilleur < 0) {
        return {"Lidar 360", Statut::ERREUR, "connecté mais aucun tour reçu (moteur bloqué ?)", true};
    }

    ResultatTest r = evaluerLidar360(meilleur, meilleurTour);
    if (lidar.getSante() == 1 && r.statut == Statut::OK) {
        r.statut = Statut::ALERTE;
        r.detail += " ; avertissement du lidar (code " + hex(lidar.getCodeErreur()) + ")";
    }
    r.detail += " | " + lidar.getInfos();
    return r;
}

ResultatTest Checkup::evaluerLidar360(int nbMesures, const std::array<int, 360> &d)
{
    ResultatTest r{"Lidar 360"};
    r.critique = true;

    if (nbMesures == 0) {
        r.statut = Statut::ERREUR;
        r.detail = "aucune mesure : moteur arrêté ou fenêtre du lidar masquée";
        return r;
    }

    // Obstacle le plus proche, et présence de mesures devant (± 30°)
    int dMin = 0, angleMin = 0;
    bool devant = false;
    for (int i = 0; i < 360; i++) {
        if (d[i] <= 0) continue;
        if (dMin == 0 || d[i] < dMin) { dMin = d[i]; angleMin = i - 180; }
        if (i >= 150 && i <= 210) devant = true;
    }

    QString mesure = QString("%1/360 directions mesurées, obstacle le plus proche %2 mm à %3°")
                         .arg(nbMesures).arg(dMin).arg(angleMin);

    if (nbMesures < 90) {
        r.statut = Statut::ERREUR;
        r.detail = mesure + " : lidar masqué ?";
    } else if (nbMesures < 180) {
        r.statut = Statut::ALERTE;
        r.detail = mesure + " : beaucoup de directions sans écho";
    } else if (!devant) {
        r.statut = Statut::ALERTE;
        r.detail = mesure + " : rien mesuré devant (± 30°)";
    } else {
        r.detail = mesure;
    }
    return r;
}

// ------------------------------------------------------------ TFmini (lidars des côtés)

ResultatTest Checkup::testTfMini(unsigned char adresse, const QString &cote)
{
    const QString nom = "TFmini " + cote;

    if (busExplore && !adressesI2C.contains(adresse)) {
        return {nom, Statut::ERREUR, "absent du bus en " + hex(adresse) + " (câble ? adresse ?)"};
    }

    try {
        TfMini capteur(adresse);
        QList<MesureTfMini> reponses;
        const int nbEssais = 10;
        for (int i = 0; i < nbEssais; i++) {
            if (capteur.lire()) reponses << capteur.getMesure();
            attendre(20);
        }
        ResultatTest r = evaluerTfMini(nom, nbEssais, reponses);
        r.detail = hex(adresse) + " : " + r.detail;
        return r;
    } catch (const std::exception &) {
        return {nom, Statut::ERREUR, "bus I2C inaccessible"};
    }
}

ResultatTest Checkup::evaluerTfMini(const QString &nom, int nbEssais, const QList<MesureTfMini> &reponses)
{
    ResultatTest r{nom};

    if (reponses.isEmpty()) {
        r.statut = Statut::ERREUR;
        r.detail = "aucune réponse I2C (câble, alimentation ou adresse)";
        return r;
    }

    QString remarque;
    if (reponses.size() < nbEssais) {
        r.statut = Statut::ALERTE;
        remarque = QString(" ; réponses intermittentes (%1/%2)").arg(reponses.size()).arg(nbEssais);
    }

    QList<int> distances;
    int forceMax = 0;
    for (const MesureTfMini &m : reponses) {
        if (m.signal) distances << m.distanceCm;
        forceMax = qMax(forceMax, m.force);
    }

    if (distances.isEmpty()) {
        r.statut = Statut::ALERTE;
        r.detail = "répond, mais aucune cible (rien à portée, ou capteur masqué / sale)" + remarque;
        return r;
    }

    std::sort(distances.begin(), distances.end());
    int mediane = distances.at(distances.size() / 2);
    QString mesure = QString("%1 cm (médiane), force %2").arg(mediane).arg(forceMax);

    if (mediane < TfMini::DISTANCE_MIN_CM) {
        r.statut = Statut::ALERTE;
        r.detail = mesure + " : obstacle dans la zone aveugle (< 30 cm), mesure non fiable" + remarque;
    } else {
        r.detail = mesure + remarque;
    }
    return r;
}

// ------------------------------------------------------------ réseau

ResultatTest Checkup::testReseau()
{
    QStringList adresses;
    for (const QNetworkInterface &itf : QNetworkInterface::allInterfaces()) {
        bool active = itf.flags().testFlag(QNetworkInterface::IsUp)
                   && itf.flags().testFlag(QNetworkInterface::IsRunning);
        if (!active || itf.flags().testFlag(QNetworkInterface::IsLoopBack)) continue;
        for (const QNetworkAddressEntry &e : itf.addressEntries()) {
            if (e.ip().protocol() == QAbstractSocket::IPv4Protocol)
                adresses << e.ip().toString() + " (" + itf.humanReadableName() + ")";
        }
    }

    if (adresses.isEmpty())
        return {"Réseau", Statut::ERREUR, "aucune adresse IP : la supervision ne pourra pas se connecter (wifi ?)"};

    return {"Réseau", Statut::OK, "IP " + adresses.join(", ") + " : à mettre dans IP_VOITURE de la supervision"};
}

// ------------------------------------------------------------ TCP

ResultatTest Checkup::testTcp()
{
    ResultatTest r{"TCP"};

    // 1. Les ports de la supervision doivent être libres
    QStringList occupes;
    for (int port : {portVoiture, portLidar}) {
        QTcpServer essai;
        if (!essai.listen(QHostAddress::Any, port)) occupes << QString::number(port);
        essai.close();
    }

    // 2. Échange local avec les classes de l'équipe : TcpClient -> TcpServeur, puis l'inverse
    QTcpServer chercheur;                                  // trouve un port libre pour l'essai
    chercheur.listen(QHostAddress::LocalHost, 0);
    int portEssai = chercheur.serverPort();
    chercheur.close();

    TcpServeur serveur(portEssai);
    TcpClient client("127.0.0.1", portEssai);
    QString recuParServeur, recuParClient;
    connect(&serveur, &TcpServeur::newDatas, this, [&](QString s) { recuParServeur = s; });
    connect(&client,  &TcpClient::newDatas,  this, [&](QString s) { recuParClient = s; });

    QElapsedTimer chrono;
    chrono.start();
    while (recuParServeur != "PING" && chrono.elapsed() < 2000) {
        client.sendDatas("PING");        // ignoré tant que la connexion n'est pas établie
        attendre(50);
    }
    while (recuParServeur == "PING" && recuParClient != "PONG" && chrono.elapsed() < 3000) {
        serveur.sendDatas("PONG");
        attendre(50);
    }
    disconnect(&serveur, nullptr, this, nullptr);
    disconnect(&client,  nullptr, this, nullptr);

    QString echange;
    if (recuParServeur != "PING")      echange = "échange local échoué (client -> serveur)";
    else if (recuParClient != "PONG")  echange = "échange local échoué (serveur -> client)";
    else                               echange = QString("échange local client <-> serveur réussi (%1 ms)").arg(chrono.elapsed());

    QString ports = occupes.isEmpty()
        ? QString("ports %1 et %2 libres").arg(portVoiture).arg(portLidar)
        : "port(s) " + occupes.join(" et ") + " déjà utilisé(s) : programme voiture déjà lancé ?";

    r.detail = ports + " ; " + echange;
    if (!occupes.isEmpty() || recuParClient != "PONG") r.statut = Statut::ERREUR;
    return r;
}

// ------------------------------------------------------------ bilan

QList<ResultatTest> Checkup::getResultats() const
{
    return resultats;
}

bool Checkup::departAutorise() const
{
    for (const ResultatTest &r : resultats)
        if (r.critique && r.statut == Statut::ERREUR) return false;
    return true;
}

QString Checkup::rapport() const
{
    int nbOk = 0, nbAlertes = 0, nbErreurs = 0;
    QStringList lignes, bloquants;
    for (const ResultatTest &r : resultats) {
        lignes << r.ligne();
        if (r.statut == Statut::OK) nbOk++;
        else if (r.statut == Statut::ALERTE) nbAlertes++;
        else {
            nbErreurs++;
            if (r.critique) bloquants << r.nom;
        }
    }

    QString texte = "========== CHECKUP VOITURE ==========\n" + lignes.join("\n") + "\n";
    texte += QString("Bilan : %1 OK, %2 alerte(s), %3 erreur(s)\n").arg(nbOk).arg(nbAlertes).arg(nbErreurs);
    texte += departAutorise() ? "DÉPART AUTORISÉ"
                              : "DÉPART INTERDIT (erreur critique : " + bloquants.join(", ") + ")";
    return texte;
}

// ------------------------------------------------------------ outils

void Checkup::attendre(int ms)
{
    QElapsedTimer chrono;
    chrono.start();
    while (chrono.elapsed() < ms)
        QCoreApplication::processEvents(QEventLoop::AllEvents, 10);
}

QString Checkup::hex(int valeur)
{
    return "0x" + QString::number(valeur, 16).toUpper();
}
