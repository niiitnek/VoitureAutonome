#ifndef CHECKUP_H
#define CHECKUP_H

// CHECKUP de la voiture, au démarrage ou en maintenance.
// Chaque test crée lui-même le matériel qu'il vérifie, puis le libère :
// un composant absent donne une ERREUR dans le rapport au lieu de faire planter le programme.
// À lancer AVANT de créer MaterielReel (le lidar et le bus I2C sont alors libres).

#include <QObject>
#include <QString>
#include <QList>
#include <array>
#include "tedsbatterie.h"
#include "tfmini.h"

enum class Statut { OK, ALERTE, ERREUR };

struct ResultatTest
{
    ResultatTest(const QString &_nom = QString(), Statut _statut = Statut::OK,
                 const QString &_detail = QString(), bool _critique = false)
        : nom(_nom), statut(_statut), detail(_detail), critique(_critique) {}

    QString nom;
    Statut statut;
    QString detail;
    bool critique;            // en ERREUR, interdit le départ de la voiture

    QString ligne() const;    // ex. "[OK]      Batterie        : 7.85 V (77 %)"
};

class Checkup : public QObject
{
    Q_OBJECT
public:
    explicit Checkup(QObject *parent = nullptr);

    // ---- Réglages, à modifier avant lancer()
    TedsBatterie teds;                         // fiche du capteur de tension
    unsigned char adresseTfGauche = 0x10;      // à vérifier avec  i2cdetect -y 1
    unsigned char adresseTfDroite = 0x11;
    QString portSerieLidar = "/dev/ttyUSB0";
    int portVoiture = 1234;                    // ports de la supervision (mainwindow.cpp)
    int portLidar   = 4321;

    // ---- Lancement
    QList<ResultatTest> lancer();              // tous les tests, dans l'ordre

    // Chaque test peut aussi être lancé seul (maintenance)
    ResultatTest testBusI2C();
    ResultatTest testBatterie();
    ResultatTest testLidar360();
    ResultatTest testTfMini(unsigned char adresse, const QString &cote);
    ResultatTest testReseau();
    ResultatTest testTcp();

    // ---- Bilan
    QList<ResultatTest> getResultats() const;
    bool departAutorise() const;               // aucun test critique en ERREUR
    QString rapport() const;

    // ---- Règles de décision, sans matériel : testables sur PC
    static ResultatTest evaluerBatterie(double tension, int valeurBrute, const TedsBatterie &teds);
    static ResultatTest evaluerLidar360(int nbMesures, const std::array<int, 360> &distances);
    static ResultatTest evaluerTfMini(const QString &nom, int nbEssais, const QList<MesureTfMini> &reponses);

signals:
    void nouveauResultat(const QString &ligne);   // émis à la fin de chaque test

private:
    QList<ResultatTest> resultats;
    QList<int> adressesI2C;                       // composants trouvés par testBusI2C()
    bool busExplore = false;

    void ajouter(const ResultatTest &r);
    static void attendre(int ms);                 // attend en laissant Qt traiter les événements
    static QString hex(int valeur);               // 0x4D
};

#endif // CHECKUP_H
