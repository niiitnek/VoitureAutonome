QT += core network
QT -= gui
CONFIG += c++17 console
CONFIG -= app_bundle

SOURCES += \
    main.cpp \
    checkup.cpp \
    qi2cdevice.cpp \
    tedsbatterie.cpp \
    capteurtension.cpp \
    tfmini.cpp \
    rplidar.cpp \
    tcpserveur.cpp \
    tcpclient.cpp

HEADERS += \
    checkup.h \
    qi2cdevice.h \
    tedsbatterie.h \
    capteurtension.h \
    tfmini.h \
    rplidar.h \
    tcpserveur.h \
    tcpclient.h

# Fichier visible dans Qt Creator (ne le copie pas : c'est INSTALLS, en bas, qui le copie)
DISTFILES += teds_batterie.json

# SDK du lidar 360 (chemins du wiki). Pour un autre emplacement :  qmake RPLIDAR_SDK=/chemin
isEmpty(RPLIDAR_SDK): RPLIDAR_SDK = /opt/electronique/pi4TpInfo/sysroot/rplidar/rplidar_sdk

unix:!macx: LIBS += -L$$RPLIDAR_SDK/output/Linux/Release/ -lsl_lidar_sdk
INCLUDEPATH += $$RPLIDAR_SDK/sdk/include
INCLUDEPATH += $$RPLIDAR_SDK/sdk/src
DEPENDPATH += $$RPLIDAR_SDK/sdk/include
unix:!macx: PRE_TARGETDEPS += $$RPLIDAR_SDK/output/Linux/Release/libsl_lidar_sdk.a

# Déploiement sur la Raspberry Pi : l'exécutable ET la TEDS dans le même dossier
target.path = /home/geii/checkup      # dossier où tourne le checkup sur la Pi
teds.files = teds_batterie.json
teds.path = $${target.path}
INSTALLS += target teds
