#include "rplidar.h"
#include <QtMath>
#include <QDebug>

using namespace sl;

#ifndef _countof
#define _countof(_Array) (int)(sizeof(_Array) / sizeof(_Array[0]))
#endif

RpLidar::RpLidar(std::array<int, 360> &_distances, const QString &port, int vitesse)
    : distances(_distances)
{
    // --- Création du driver et du canal série (code du wiki)
    Result<ILidarDriver *> resDrv = createLidarDriver();
    if (!resDrv) { qDebug() << "lidar : impossible de créer le driver"; return; }
    drv = *resDrv;

    Result<IChannel *> resCanal = createSerialPortChannel(port.toStdString(), vitesse);
    if (!resCanal) { qDebug() << "lidar : impossible de créer le canal série"; return; }

    // --- Connexion : le port s'ouvre, puis le lidar doit répondre
    if (SL_IS_FAIL(drv->connect(*resCanal))) {
        qDebug() << "lidar : port" << port << "inaccessible";
        return;
    }

    sl_lidar_response_device_info_t devinfo;
    if (SL_IS_FAIL(drv->getDeviceInfo(devinfo))) {
        qDebug() << "lidar : aucune réponse sur" << port;
        return;
    }
    connecte = true;

    QString numeroSerie;
    for (int i = 0; i < 16; i++) numeroSerie += QString("%1").arg(devinfo.serialnum[i], 2, 16, QChar('0'));
    infos = QString("modèle %1, firmware %2.%3, matériel %4, n° %5")
                .arg(devinfo.model)
                .arg(devinfo.firmware_version >> 8)
                .arg(devinfo.firmware_version & 0xFF, 2, 10, QChar('0'))
                .arg(devinfo.hardware_version)
                .arg(numeroSerie.toUpper());

    // --- Santé déclarée par le lidar lui-même
    sl_lidar_response_device_health_t health;
    if (SL_IS_OK(drv->getHealth(health))) {
        sante = health.status;          // SL_LIDAR_STATUS_OK / WARNING / ERROR
        codeErreur = health.error_code;
    }

    // --- Démarrage du moteur et du balayage (code du wiki)
    drv->setMotorSpeed();
    drv->startScan(0, 1);
}

RpLidar::~RpLidar()
{
    if (drv == nullptr) return;
    if (connecte) {
        drv->stop();
        drv->setMotorSpeed(0);      // arrête le moteur
    }
    drv->disconnect();
    delete drv;                     // libère le port série pour le programme suivant
}

bool RpLidar::update()
{
    if (!connecte) return false;

    sl_lidar_response_measurement_node_hq_t nodes[8192];
    size_t count = _countof(nodes);
    sl_result op_result = drv->grabScanDataHq(nodes, count);
    if (!SL_IS_OK(op_result)) return false;

    // Conversion en 360 cases (code du wiki)
    distances.fill(0);
    for (int i = 0; i < (int)count; i++) {
        int angle = round((nodes[i].angle_z_q14 * 90.f) / 16384.f);
        if (angle >= 180) angle -= 360;
        if ((angle >= -180) and (angle < 180)) {
            int d = nodes[i].dist_mm_q2 / 4.0;
            if (d > 0) distances.at(angle + 180) = d;
        }
    }

    // AJOUT checkup : nombre de directions réellement mesurées, avant de boucher les trous
    nbMesures = 0;
    for (int d : distances) if (d > 0) nbMesures++;

    // Bouchage des trous par une mesure voisine (code du wiki)
    for (int i = 0; i < 360; i++) {
        if (distances.at(i) == 0) {
            for (int j = 1; j < 10; j++) {
                int pos = (i + j) % 360;
                if (distances.at(pos) != 0) distances.at(i) = distances.at(pos);
            }
        }
    }
    return true;
}

bool RpLidar::estConnecte() const  { return connecte; }
QString RpLidar::getInfos() const  { return infos; }
int RpLidar::getSante() const      { return sante; }
int RpLidar::getCodeErreur() const { return codeErreur; }
int RpLidar::getNbMesures() const  { return nbMesures; }
