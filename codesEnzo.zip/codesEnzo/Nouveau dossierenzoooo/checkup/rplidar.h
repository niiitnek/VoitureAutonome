#ifndef RPLIDAR_H
#define RPLIDAR_H

// Lidar 360° Slamtec RPLidar, d'après le code du wiki,
// avec en plus ce qu'il faut pour le checkup (identité, santé, nombre de mesures).

#include "sl_lidar_driver.h"
#include <QObject>
#include <QString>
#include <array>

class RpLidar : public QObject
{
    Q_OBJECT
public:
    // distances : le tableau partagé (case i = angle i - 180, en mm)
    explicit RpLidar(std::array<int, 360> &_distances,
                     const QString &port = "/dev/ttyUSB0", int vitesse = 115200);
    ~RpLidar() override;      // arrête le moteur et libère le port série

    bool estConnecte() const;     // le lidar a répondu à getDeviceInfo
    QString getInfos() const;     // modèle, n° de série, firmware, matériel
    int getSante() const;         // 0 OK, 1 avertissement, 2 erreur, -1 inconnue
    int getCodeErreur() const;    // code d'erreur fourni par le lidar
    int getNbMesures() const;     // directions mesurées au dernier tour (0..360), avant bouchage des trous

public slots:
    bool update();                // lit un tour ; false si la lecture a échoué

private:
    std::array<int, 360> &distances;
    sl::ILidarDriver *drv = nullptr;
    bool connecte = false;
    QString infos;
    int sante = -1;
    int codeErreur = 0;
    int nbMesures = 0;
};

#endif // RPLIDAR_H
