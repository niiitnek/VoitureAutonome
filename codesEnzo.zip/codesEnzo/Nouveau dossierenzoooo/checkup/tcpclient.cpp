#include "tcpclient.h"

TcpClient::TcpClient(QString ip, int port)
{
    dataIn.setDevice(&clientSocket);
    dataIn.setVersion(QDataStream::Qt_5_0);   // même version que l'émetteur
    connect(&clientSocket, &QTcpSocket::readyRead, this, &TcpClient::readyRead);
    clientSocket.connectToHost(ip, port);
}

void TcpClient::sendDatas(QString datas)
{
    // Pas (encore) connecté au serveur : on n'envoie rien
    if (clientSocket.state() != QAbstractSocket::ConnectedState) return;

    // 1. On construit la trame complète en mémoire
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_0);
    out << datas;                    // écrit la longueur, puis les caractères
    // qDebug() << "message envoyé :" << datas;

    // 2. On l'envoie en une seule fois
    clientSocket.write(block);
}

void TcpClient::readyRead()
{
    // Plusieurs trames peuvent arriver d'un coup (ex. : slider déplacé vite).
    // On les lit toutes, une par une.
    while (true) {
        dataIn.startTransaction();
        QString datas;
        dataIn >> datas;
        if (!dataIn.commitTransaction()) return;   // trame incomplète : on attend la suite
        emit newDatas(datas);
    }
}
