#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QTcpSocket>
#include <QDataStream>

class TcpClient : public QObject
{
    Q_OBJECT
public:
     TcpClient(QString ip, int port);

public slots:
    void sendDatas(QString datas);

private slots:
    void readyRead();

signals:
    void newDatas(QString datas);

private:
    QTcpSocket clientSocket;
    QDataStream dataIn;};

#endif // TCPCLIENT_H