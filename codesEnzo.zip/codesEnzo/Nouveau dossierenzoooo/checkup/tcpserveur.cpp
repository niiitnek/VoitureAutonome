#include "tcpserveur.h"

TcpServeur::TcpServeur(int port)
{
    dataIn.setVersion(QDataStream::Qt_5_0);   // même version que l'émetteur
    connect(&monServeur, &QTcpServer::newConnection, this, &TcpServeur::newConnection);
    monServeur.listen(QHostAddress::Any, port);
}

void TcpServeur::newConnection()
{
    serveurSocket = monServeur.nextPendingConnection();
    dataIn.setDevice(serveurSocket);
    connect(serveurSocket, &QTcpSocket::readyRead, this, &TcpServeur::readyRead);
}

void TcpServeur::sendDatas(QString datas)
{
    // Aucun client connecté : serveurSocket vaut nullptr.
    // Sans ce test, serveurSocket->write() ferait planter le programme.
    if (serveurSocket == nullptr) return;

    // 1. On construit la trame complète en mémoire
    QByteArray block;
    QDataStream out(&block, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_5_0);
    out << datas;                    // écrit la longueur, puis les caractères
    // qDebug() << "message envoyé :" << datas;

    // 2. On l'envoie en une seule fois
    serveurSocket->write(block);
}

void TcpServeur::readyRead()
{
    // Plusieurs trames peuvent arriver d'un coup : on les lit toutes.
    while (true) {
        dataIn.startTransaction();
        QString datas;
        dataIn >> datas;
        if (!dataIn.commitTransaction()) return;   // trame incomplète : on attend la suite
        emit newDatas(datas);
    }
}
