#ifndef TCPSERVEUR_H
#define TCPSERVEUR_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QDataStream>

class TcpServeur : public QObject
{
    Q_OBJECT
public:
     TcpServeur(int port);

public slots:
     void sendDatas(QString datas);

private slots:
    void newConnection();
    void readyRead();

signals:
    void newDatas(QString datas);

private:
    QTcpServer monServeur;
    QTcpSocket *serveurSocket = nullptr;
    QDataStream dataIn;
};

#endif // TCPSERVEUR_H