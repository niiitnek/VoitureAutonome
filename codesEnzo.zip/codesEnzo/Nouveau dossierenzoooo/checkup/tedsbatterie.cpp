#include "tedsbatterie.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QtGlobal>

bool TedsBatterie::charger(const QString &chemin)
{
    QFile fichier(chemin);
    if (!fichier.open(QIODevice::ReadOnly)) return false;

    QJsonObject j = QJsonDocument::fromJson(fichier.readAll()).object();
    if (j.isEmpty()) return false;

    // Chaque champ absent du fichier garde sa valeur par défaut
    fabricant      = j.value("fabricant").toString(fabricant);
    modele         = j.value("modele").toString(modele);
    adresseI2C     = j.value("adresseI2C").toString(QString::number(adresseI2C, 16)).toInt(nullptr, 16);
    resolutionBits = j.value("resolutionBits").toInt(resolutionBits);
    vref           = j.value("vref").toDouble(vref);
    rapportPont    = j.value("rapportPont").toDouble(rapportPont);
    tensionVide    = j.value("tensionVide").toDouble(tensionVide);
    tensionAlerte  = j.value("tensionAlerte").toDouble(tensionAlerte);
    tensionPleine  = j.value("tensionPleine").toDouble(tensionPleine);
    dateEtalonnage = j.value("dateEtalonnage").toString(dateEtalonnage);
    return true;
}

bool TedsBatterie::sauver(const QString &chemin) const
{
    QJsonObject j;
    j["fabricant"]      = fabricant;
    j["modele"]         = modele;
    j["adresseI2C"]     = QString::number(adresseI2C, 16);   // en hexadécimal, ex. "4d"
    j["resolutionBits"] = resolutionBits;
    j["vref"]           = vref;
    j["rapportPont"]    = rapportPont;
    j["tensionVide"]    = tensionVide;
    j["tensionAlerte"]  = tensionAlerte;
    j["tensionPleine"]  = tensionPleine;
    j["dateEtalonnage"] = dateEtalonnage;

    QFile fichier(chemin);
    if (!fichier.open(QIODevice::WriteOnly | QIODevice::Truncate)) return false;
    fichier.write(QJsonDocument(j).toJson());
    return true;
}

double TedsBatterie::convertir(int valeurBrute) const
{
    const int maxi = (1 << resolutionBits) - 1;                // 1023 pour 10 bits
    double tensionAdc = valeurBrute * vref / maxi;             // tension sur l'entrée de l'ADC
    return tensionAdc * rapportPont;                           // tension de la batterie
}

double TedsBatterie::tensionMaxMesurable() const
{
    return vref * rapportPont;
}

int TedsBatterie::pourcentage(double tension) const
{
    double p = (tension - tensionVide) / (tensionPleine - tensionVide) * 100.0;
    return qRound(qBound(0.0, p, 100.0));
}

QString TedsBatterie::description() const
{
    return QString("%1 %2 en 0x%3, %4 bits, Vref %5 V, pont x%6, batterie %7–%8 V, étalonnage : %9")
        .arg(fabricant, modele, QString::number(adresseI2C, 16))
        .arg(resolutionBits).arg(vref).arg(rapportPont)
        .arg(tensionVide).arg(tensionPleine).arg(dateEtalonnage);
}
