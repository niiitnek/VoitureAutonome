#ifndef TEDSBATTERIE_H
#define TEDSBATTERIE_H

#include <QString>

// TEDS (Transducer Electronic Data Sheet, norme IEEE 1451) du capteur de tension batterie :
// la "carte d'identité" du capteur, qui dit qui il est et comment interpréter sa mesure.
// Le MCP3021 n'a pas de mémoire pour la stocker : on utilise une TEDS VIRTUELLE,
// un fichier JSON posé à côté du programme. Sans fichier, les valeurs ci-dessous s'appliquent.
class TedsBatterie
{
public:
    // --- Identification du capteur
    QString fabricant   = "Microchip";
    QString modele      = "MCP3021A1T";   // trouvé en 0x49 sur la voiture (le schéma v2 indiquait A5 / 0x4D)
    int     adresseI2C  = 0x49;
    int     resolutionBits = 10;          // valeur brute de 0 à 1023

    // --- Conversion de la mesure
    double vref        = 3.3;             // V : tension de référence (= alimentation du MCP3021)
    double rapportPont = 2.8;             // pont diviseur (18 kΩ + 10 kΩ) / 10 kΩ

    // --- Batterie surveillée
    double tensionVide   = 6.0;           // V : 0 %
    double tensionAlerte = 6.6;           // V : en dessous, recharger
    double tensionPleine = 8.4;           // V : 100 %

    // --- Maintenance
    QString dateEtalonnage = "non étalonné";

    bool charger(const QString &chemin);              // true si le fichier a été lu
    bool sauver(const QString &chemin) const;         // écrit la TEDS dans un fichier JSON
    double convertir(int valeurBrute) const;          // brute (0..1023) -> tension batterie (V)
    double tensionMaxMesurable() const;               // vref x rapportPont
    int pourcentage(double tension) const;            // 0..100 %
    QString description() const;                      // résumé lisible
};

#endif // TEDSBATTERIE_H
