#include "tfmini.h"

TfMini::TfMini(unsigned char _adresse, I2C_BUS bus)
    : adresse(_adresse)
    , i2c(bus, _adresse)     // lève une exception si le bus I2C n'existe pas
{
}

bool TfMini::lire()
{
    // Registre 0x0102 (octet haut, octet bas), puis le nombre d'octets voulus
    const unsigned char commande[3] = {0x01, 0x02, 0x07};
    unsigned char trame[7] = {0};

    if (!i2c.transfert(commande, 3, trame, 7)) return false;   // pas de réponse

    derniere = decoder(trame);
    return true;
}

MesureTfMini TfMini::decoder(const unsigned char trame[7])
{
    MesureTfMini m;
    int distance = trame[2] | (trame[3] << 8);    // octet bas en premier
    m.force      = trame[4] | (trame[5] << 8);
    m.mode       = trame[6];

    if (distance == 0xFFFF) {        // force sous le seuil (20) : mesure non fiable
        m.signal = false;
        m.distanceCm = -1;
    } else {
        m.signal = true;
        m.distanceCm = distance;
    }
    return m;
}

bool TfMini::changerAdresse(unsigned char nouvelleAdresse)
{
    if (nouvelleAdresse < 0x10 || nouvelleAdresse > 0x78) return false;

    // Écriture d'un registre : adresse haute, adresse basse, nombre d'octets, valeur
    const unsigned char commande[4] = {0x00, 0x26, 0x01, nouvelleAdresse};
    return i2c.transfert(commande, 4, nullptr, 0);
}

MesureTfMini TfMini::getMesure() const     { return derniere; }
int TfMini::getDistance() const            { return derniere.distanceCm; }
int TfMini::getForce() const               { return derniere.force; }
unsigned char TfMini::getAdresse() const   { return adresse; }
