#ifndef TFMINI_H
#define TFMINI_H

#include "qi2cdevice.h"

// Lidar mono-point Benewake TFmini, version I2C (manuel TFmini-I2C V1.1).
//   - adresse I2C par défaut : 0x10 (de 0x10 à 0x78)
//   - lecture : on écrit 01 02 07 (registre 0x0102, 7 octets), puis on lit 7 octets
//   - distance en cm par défaut, de 30 cm (zone aveugle en dessous) à 1200 cm
//   - mesure renouvelée 100 fois par seconde

struct MesureTfMini
{
    bool signal = false;   // false : signal trop faible (Dist = 0xFFFF), pas de cible fiable
    int distanceCm = -1;   // distance en cm, -1 si pas de signal
    int force = 0;         // force du signal : fiable entre 20 et 2000
    int mode = 0;          // portée utilisée : 0x00 courte, 0x03 moyenne, 0x07 longue
};

class TfMini
{
public:
    explicit TfMini(unsigned char adresse = 0x10, I2C_BUS bus = I2C1);

    bool lire();                       // nouvelle mesure ; false si le capteur ne répond pas
    MesureTfMini getMesure() const;    // dernière mesure lue
    int getDistance() const;           // en cm, -1 si pas de signal
    int getForce() const;
    unsigned char getAdresse() const;

    // Décode les 7 octets reçus. Statique : se teste sur PC, sans capteur.
    //   [0] trigger  [1] réservé  [2] dist bas  [3] dist haut
    //   [4] force bas  [5] force haut  [6] mode
    static MesureTfMini decoder(const unsigned char trame[7]);

    // MAINTENANCE : change l'adresse I2C (registre 0x0026), de 0x10 à 0x78.
    // Brancher UN SEUL TFmini à la fois. Prise en compte après coupure de l'alimentation.
    bool changerAdresse(unsigned char nouvelleAdresse);

    static const int DISTANCE_MIN_CM = 30;     // en dessous : zone aveugle
    static const int DISTANCE_MAX_CM = 1200;

private:
    unsigned char adresse;
    QI2cDevice i2c;
    MesureTfMini derniere;
};

#endif // TFMINI_H
