QT += core network testlib
QT -= gui
CONFIG += c++17 console testcase
CONFIG -= app_bundle

# Les classes testées sont dans le dossier du checkup
INCLUDEPATH += ../../checkup

SOURCES += \
    testcheckup.cpp \
    ../../checkup/checkup.cpp \
    ../../checkup/qi2cdevice.cpp \
    ../../checkup/tedsbatterie.cpp \
    ../../checkup/capteurtension.cpp \
    ../../checkup/tfmini.cpp \
    ../../checkup/rplidar.cpp \
    ../../checkup/tcpserveur.cpp \
    ../../checkup/tcpclient.cpp

HEADERS += \
    testcheckup.h \
    ../../checkup/checkup.h \
    ../../checkup/qi2cdevice.h \
    ../../checkup/tedsbatterie.h \
    ../../checkup/capteurtension.h \
    ../../checkup/tfmini.h \
    ../../checkup/rplidar.h \
    ../../checkup/tcpserveur.h \
    ../../checkup/tcpclient.h

# SDK du lidar 360 (chemins du wiki). Pour un autre emplacement :  qmake RPLIDAR_SDK=/chemin
isEmpty(RPLIDAR_SDK): RPLIDAR_SDK = /opt/electronique/pi4TpInfo/sysroot/rplidar/rplidar_sdk

unix:!macx: LIBS += -L$$RPLIDAR_SDK/output/Linux/Release/ -lsl_lidar_sdk
INCLUDEPATH += $$RPLIDAR_SDK/sdk/include
INCLUDEPATH += $$RPLIDAR_SDK/sdk/src
DEPENDPATH += $$RPLIDAR_SDK/sdk/include
unix:!macx: PRE_TARGETDEPS += $$RPLIDAR_SDK/output/Linux/Release/libsl_lidar_sdk.a
