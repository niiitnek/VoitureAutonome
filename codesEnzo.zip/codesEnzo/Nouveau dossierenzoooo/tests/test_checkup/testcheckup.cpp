#include "testcheckup.h"
#include "checkup.h"
#include "tedsbatterie.h"
#include <QTemporaryDir>

TestCheckup::TestCheckup(QObject *parent)
    : QObject{parent}
{
}

// ---------------------------------------------------------------- TEDS

void TestCheckup::tedsConversion_data()
{
    QTest::addColumn<int>("brute");
    QTest::addColumn<double>("tension");

    // tension = brute x 3.3 / 1023 x 2.8
    QTest::newRow("zéro")        <<    0 << 0.0;
    QTest::newRow("pleine 8.4V") <<  930 << 8.4;
    QTest::newRow("max 9.24V")   << 1023 << 9.24;
}

void TestCheckup::tedsConversion()
{
    QFETCH(int, brute);
    QFETCH(double, tension);
    TedsBatterie teds;                                   // valeurs par défaut
    QVERIFY(qAbs(teds.convertir(brute) - tension) < 0.01);
}

void TestCheckup::tedsFichier()
{
    QTemporaryDir dossier;
    QString chemin = dossier.filePath("teds.json");

    TedsBatterie ecrite;
    ecrite.adresseI2C = 0x4D;
    ecrite.rapportPont = 2.75;
    ecrite.dateEtalonnage = "14/10/2026";
    QVERIFY(ecrite.sauver(chemin));

    TedsBatterie lue;
    QVERIFY(lue.charger(chemin));
    QCOMPARE(lue.adresseI2C, 0x4D);
    QCOMPARE(lue.rapportPont, 2.75);
    QCOMPARE(lue.dateEtalonnage, QString("14/10/2026"));

    TedsBatterie absente;
    QVERIFY(!absente.charger(dossier.filePath("inexistant.json")));
    QCOMPARE(absente.adresseI2C, 0x49);                  // garde ses valeurs par défaut
}

// ---------------------------------------------------------------- batterie

void TestCheckup::evaluerBatterie_data()
{
    QTest::addColumn<double>("tension");
    QTest::addColumn<int>("brute");
    QTest::addColumn<int>("statut");

    QTest::newRow("normale")         << 7.80 <<  864 << int(Statut::OK);
    QTest::newRow("pleine")          << 8.40 <<  930 << int(Statut::OK);
    QTest::newRow("faible")          << 6.30 <<  698 << int(Statut::ALERTE);
    QTest::newRow("vide")            << 5.50 <<  609 << int(Statut::ERREUR);
    QTest::newRow("débranchée")      << 0.10 <<   11 << int(Statut::ERREUR);
    QTest::newRow("trop haute")      << 9.00 <<  996 << int(Statut::ALERTE);
    QTest::newRow("ADC saturé")      << 9.24 << 1023 << int(Statut::ERREUR);
}

void TestCheckup::evaluerBatterie()
{
    QFETCH(double, tension);
    QFETCH(int, brute);
    QFETCH(int, statut);

    ResultatTest r = Checkup::evaluerBatterie(tension, brute, TedsBatterie());
    QCOMPARE(int(r.statut), statut);
    QVERIFY(r.critique);                                 // la batterie est un test bloquant
}

// ---------------------------------------------------------------- lidar 360

static std::array<int, 360> tour(int nbMesures, bool devant)
{
    std::array<int, 360> d{};
    // nbMesures cases remplies, en partant de l'arrière
    for (int i = 0; i < nbMesures && i < 360; i++) d[(i + 211) % 360] = 1000 + i;
    if (!devant) for (int i = 150; i <= 210; i++) d[i] = 0;
    return d;
}

void TestCheckup::evaluerLidar360_data()
{
    QTest::addColumn<int>("nbMesures");
    QTest::addColumn<bool>("devant");
    QTest::addColumn<int>("statut");

    QTest::newRow("aucune mesure")      <<   0 << false << int(Statut::ERREUR);
    QTest::newRow("masqué (50)")        <<  50 << false << int(Statut::ERREUR);
    QTest::newRow("partiel (150)")      << 150 << false << int(Statut::ALERTE);
    QTest::newRow("rien devant (290)")  << 290 << false << int(Statut::ALERTE);
    QTest::newRow("normal (330)")       << 330 << true  << int(Statut::OK);
}

void TestCheckup::evaluerLidar360()
{
    QFETCH(int, nbMesures);
    QFETCH(bool, devant);
    QFETCH(int, statut);

    ResultatTest r = Checkup::evaluerLidar360(nbMesures, tour(nbMesures, devant));
    QCOMPARE(int(r.statut), statut);
}

// ---------------------------------------------------------------- TFmini

static MesureTfMini mesure(int distanceCm, int force = 300)
{
    MesureTfMini m;
    m.signal = distanceCm >= 0;
    m.distanceCm = distanceCm;
    m.force = force;
    return m;
}

void TestCheckup::evaluerTfMini_data()
{
    QTest::addColumn<int>("nbReponses");
    QTest::addColumn<int>("distance");
    QTest::addColumn<int>("statut");

    QTest::newRow("muet")            <<  0 <<  85 << int(Statut::ERREUR);
    QTest::newRow("normal")          << 10 <<  85 << int(Statut::OK);
    QTest::newRow("intermittent")    <<  6 <<  85 << int(Statut::ALERTE);
    QTest::newRow("aucune cible")    << 10 <<  -1 << int(Statut::ALERTE);
    QTest::newRow("zone aveugle")    << 10 <<  20 << int(Statut::ALERTE);
}

void TestCheckup::evaluerTfMini()
{
    QFETCH(int, nbReponses);
    QFETCH(int, distance);
    QFETCH(int, statut);

    QList<MesureTfMini> reponses;
    for (int i = 0; i < nbReponses; i++) reponses << mesure(distance);

    ResultatTest r = Checkup::evaluerTfMini("TFmini", 10, reponses);
    QCOMPARE(int(r.statut), statut);
    QVERIFY(!r.critique);                                // un TFmini seul ne bloque pas le départ
}

// ---------------------------------------------------------------- TCP et bilan

void TestCheckup::testTcp()
{
    Checkup checkup;
    checkup.portVoiture = 45678;                         // ports sûrement libres sur le PC
    checkup.portLidar = 45679;
    ResultatTest r = checkup.testTcp();
    QVERIFY2(r.statut == Statut::OK, qPrintable(r.detail));
}

void TestCheckup::departAutorise()
{
    // Un checkup sans aucun test lancé autorise le départ (rien de bloquant)
    Checkup checkup;
    QVERIFY(checkup.departAutorise());
    QVERIFY(checkup.rapport().contains("DÉPART AUTORISÉ"));
}

QTEST_GUILESS_MAIN(TestCheckup)
