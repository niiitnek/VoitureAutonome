#ifndef TESTCHECKUP_H
#define TESTCHECKUP_H

#include <QtTest/QTest>
#include <QObject>

// Tests du checkup qui tournent sur PC, sans la voiture :
// les règles de décision, la TEDS, et l'échange TCP local.
class TestCheckup : public QObject
{
    Q_OBJECT
public:
    explicit TestCheckup(QObject *parent = nullptr);

private slots:
    void tedsConversion_data();
    void tedsConversion();
    void tedsFichier();

    void evaluerBatterie_data();
    void evaluerBatterie();

    void evaluerLidar360_data();
    void evaluerLidar360();

    void evaluerTfMini_data();
    void evaluerTfMini();

    void testTcp();
    void departAutorise();
};

#endif // TESTCHECKUP_H
