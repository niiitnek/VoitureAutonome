QT += core testlib
QT -= gui
CONFIG += c++17 console testcase
CONFIG -= app_bundle

# Les classes testées sont dans le dossier du checkup
INCLUDEPATH += ../../checkup

SOURCES += \
    testtfmini.cpp \
    ../../checkup/tfmini.cpp \
    ../../checkup/qi2cdevice.cpp

HEADERS += \
    testtfmini.h \
    ../../checkup/tfmini.h \
    ../../checkup/qi2cdevice.h
