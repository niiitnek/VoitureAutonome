#include "testtfmini.h"
#include "tfmini.h"
#include <QThread>
#include <QtGlobal>
#include <memory>
#include <algorithm>

// Adresses des deux TFmini de la voiture : à vérifier avec  i2cdetect -y 1
const unsigned char ADRESSE_GAUCHE = 0x10;
const unsigned char ADRESSE_DROITE = 0x11;

// Crée le capteur, ou renvoie nullptr si le bus I2C n'existe pas (test lancé sur PC)
static std::unique_ptr<TfMini> creerCapteur(unsigned char adresse)
{
    try {
        return std::make_unique<TfMini>(adresse);
    } catch (const std::exception &) {
        return nullptr;
    }
}

TestTfMini::TestTfMini(QObject *parent)
    : QObject{parent}
{
}

// ---------------------------------------------------------------- sans capteur

void TestTfMini::decoder_data()
{
    QTest::addColumn<QByteArray>("trame");      // les 7 octets reçus
    QTest::addColumn<bool>("signal");
    QTest::addColumn<int>("distance");
    QTest::addColumn<int>("force");
    QTest::addColumn<int>("mode");

    //                                              trig  rés.  distL distH forL  forH  mode
    QTest::newRow("85 cm")           << QByteArray("\x01\x00\x55\x00\x54\x01\x00", 7) << true  <<   85 << 340 << 0;
    QTest::newRow("300 cm")          << QByteArray("\x01\x00\x2C\x01\x64\x00\x03", 7) << true  <<  300 << 100 << 3;
    QTest::newRow("1200 cm (max)")   << QByteArray("\x01\x00\xB0\x04\x15\x00\x07", 7) << true  << 1200 <<  21 << 7;
    QTest::newRow("zone aveugle")    << QByteArray("\x01\x00\x0C\x00\xB8\x0B\x00", 7) << true  <<   12 << 3000 << 0;
    QTest::newRow("signal faible")   << QByteArray("\x01\x00\xFF\xFF\x0A\x00\x07", 7) << false <<   -1 <<  10 << 7;
}

void TestTfMini::decoder()
{
    QFETCH(QByteArray, trame);
    QFETCH(bool, signal);
    QFETCH(int, distance);
    QFETCH(int, force);
    QFETCH(int, mode);

    MesureTfMini m = TfMini::decoder(reinterpret_cast<const unsigned char *>(trame.constData()));

    QCOMPARE(m.signal, signal);
    QCOMPARE(m.distanceCm, distance);
    QCOMPARE(m.force, force);
    QCOMPARE(m.mode, mode);
}

// ---------------------------------------------------------------- sur la voiture

void TestTfMini::lecture_data()
{
    QTest::addColumn<int>("adresse");
    QTest::newRow("gauche") << int(ADRESSE_GAUCHE);
    QTest::newRow("droit")  << int(ADRESSE_DROITE);
}

void TestTfMini::lecture()
{
    QFETCH(int, adresse);
    auto capteur = creerCapteur(adresse);
    if (!capteur) QSKIP("bus I2C absent : test à lancer sur la voiture");

    QVERIFY2(capteur->lire(), "pas de réponse I2C (câble, alimentation ou adresse)");

    MesureTfMini m = capteur->getMesure();
    QVERIFY(m.force >= 0 && m.force <= 3000);
    QVERIFY(m.mode == 0x00 || m.mode == 0x03 || m.mode == 0x07);
    if (m.signal)
        QVERIFY(m.distanceCm >= 0 && m.distanceCm <= TfMini::DISTANCE_MAX_CM);
}

void TestTfMini::stabilite_data()
{
    lecture_data();
}

// 20 mesures, voiture et décor immobiles : l'écart doit rester dans la précision (± 4 cm)
void TestTfMini::stabilite()
{
    QFETCH(int, adresse);
    auto capteur = creerCapteur(adresse);
    if (!capteur) QSKIP("bus I2C absent : test à lancer sur la voiture");

    int reponses = 0;
    QList<int> distances;
    for (int i = 0; i < 20; i++) {
        if (capteur->lire()) {
            reponses++;
            if (capteur->getMesure().signal) distances << capteur->getDistance();
        }
        QThread::msleep(10);
    }

    QVERIFY2(reponses >= 18, "réponses I2C intermittentes");
    if (distances.size() < 10) QSKIP("aucune cible devant le capteur : placer un obstacle");

    auto [mini, maxi] = std::minmax_element(distances.begin(), distances.end());
    QVERIFY2(*maxi - *mini <= 8, qPrintable(QString("mesures instables : de %1 à %2 cm").arg(*mini).arg(*maxi)));
}

void TestTfMini::distanceConnue_data()
{
    lecture_data();
}

// Placer un obstacle plat face au capteur, puis lancer :
//     TFMINI_DISTANCE_CM=50 ./test_tfmini
void TestTfMini::distanceConnue()
{
    QFETCH(int, adresse);
    bool ok = false;
    int attendue = qEnvironmentVariableIntValue("TFMINI_DISTANCE_CM", &ok);
    if (!ok) QSKIP("définir TFMINI_DISTANCE_CM pour ce test");

    auto capteur = creerCapteur(adresse);
    if (!capteur) QSKIP("bus I2C absent : test à lancer sur la voiture");

    QList<int> distances;
    for (int i = 0; i < 20; i++) {
        if (capteur->lire() && capteur->getMesure().signal) distances << capteur->getDistance();
        QThread::msleep(10);
    }
    QVERIFY2(distances.size() >= 10, "pas assez de mesures valides");

    std::sort(distances.begin(), distances.end());
    int mediane = distances.at(distances.size() / 2);
    QVERIFY2(qAbs(mediane - attendue) <= 6,     // ± 4 cm du capteur + 2 cm de placement
             qPrintable(QString("mesuré %1 cm, attendu %2 cm").arg(mediane).arg(attendue)));
}

QTEST_APPLESS_MAIN(TestTfMini)
