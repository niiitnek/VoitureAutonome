#ifndef TESTTFMINI_H
#define TESTTFMINI_H

#include <QtTest/QTest>
#include <QObject>

class TestTfMini : public QObject
{
    Q_OBJECT
public:
    explicit TestTfMini(QObject *parent = nullptr);

private slots:
    // Sans capteur (sur PC) : décodage des 7 octets
    void decoder_data();
    void decoder();

    // Sur la voiture : communication, plausibilité, stabilité
    void lecture_data();
    void lecture();
    void stabilite_data();
    void stabilite();

    // Sur la voiture, avec un obstacle placé à une distance connue
    void distanceConnue_data();
    void distanceConnue();
};

#endif // TESTTFMINI_H
