QT += core network
QT -= gui
CONFIG += c++17 console
CONFIG -= app_bundle

SOURCES += \
    main.cpp \
    checkup.cpp \
    qi2cdevice.cpp \
    tedsbatterie.cpp \
    capteurtension.cpp \
    tfmini.cpp \
    rplidar.cpp \
    tcpserveur.cpp \
    tcpclient.cpp

HEADERS += \
    checkup.h \
    qi2cdevice.h \
    tedsbatterie.h \
    capteurtension.h \
    tfmini.h \
    rplidar.h \
    tcpserveur.h \
    tcpclient.h

# La TEDS est copiée à côté du programme
DISTFILES += teds_batterie.json

# SDK du lidar 360 (chemins du wiki). Pour un autre emplacement :  qmake RPLIDAR_SDK=/chemin
isEmpty(RPLIDAR_SDK): RPLIDAR_SDK = /opt/electronique/pi4TpInfo/sysroot/rplidar/rplidar_sdk

unix:!macx: LIBS += -L$$RPLIDAR_SDK/output/Linux/Release/ -lsl_lidar_sdk
INCLUDEPATH += $$RPLIDAR_SDK/sdk/include
INCLUDEPATH += $$RPLIDAR_SDK/sdk/src
DEPENDPATH += $$RPLIDAR_SDK/sdk/include
unix:!macx: PRE_TARGETDEPS += $$RPLIDAR_SDK/output/Linux/Release/libsl_lidar_sdk.a

target.path = /home/geii/$${TARGET}
teds.files = teds_batterie.json
teds.path = $${target.path}
INSTALLS += target teds