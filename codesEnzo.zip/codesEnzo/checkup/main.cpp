// Programme de CHECKUP / MAINTENANCE de la voiture (sur la Raspberry Pi).
//
//   ./checkup                    -> lance tous les tests et affiche le rapport
//   ./checkup --etalonner 7.92   -> étalonne la mesure de batterie : 7.92 V lus au multimètre
//                                   sur la batterie ; met à jour la TEDS (teds_batterie.json)
//
// Code de retour : 0 si le départ est autorisé, 1 sinon (utilisable dans un script).

#include <QCoreApplication>
#include <QDate>
#include <QDebug>
#include "checkup.h"
#include "capteurtension.h"

static int etalonner(TedsBatterie teds, double tensionMultimetre, const QString &chemin)
{
    try {
        CapteurTension capteur(teds);
        double somme = 0;
        int n = 0;
        for (int i = 0; i < 10; i++) {
            if (capteur.getValue() >= 0) { somme += capteur.getValeurBrute(); n++; }
        }
        if (n == 0) { qInfo() << "Étalonnage impossible : le MCP3021 ne répond pas"; return 1; }

        double brute = somme / n;
        const int maxi = (1 << teds.resolutionBits) - 1;
        double tensionAdc = brute * teds.vref / maxi;

        // Le multimètre donne la vraie tension : on en déduit le vrai rapport du pont
        teds.rapportPont = tensionMultimetre / tensionAdc;
        teds.dateEtalonnage = QDate::currentDate().toString("dd/MM/yyyy");

        if (!teds.sauver(chemin)) { qInfo() << "Impossible d'écrire" << chemin; return 1; }
        qInfo().noquote() << QString("Étalonné : brute %1 -> rapportPont = %2, TEDS enregistrée dans %3")
                                 .arg(brute, 0, 'f', 1).arg(teds.rapportPont, 0, 'f', 4).arg(chemin);
        return 0;
    } catch (const std::exception &) {
        qInfo() << "Étalonnage impossible : bus I2C inaccessible";
        return 1;
    }
}

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Checkup checkup;

    // La TEDS virtuelle est un fichier JSON à côté du programme
    const QString cheminTeds = QCoreApplication::applicationDirPath() + "/teds_batterie.json";
    if (checkup.teds.charger(cheminTeds))
        qInfo().noquote() << "TEDS batterie lue :" << cheminTeds;
    else
        qInfo().noquote() << "TEDS batterie : valeurs par défaut (pas de fichier" << cheminTeds << ")";
    qInfo().noquote() << " " << checkup.teds.description();

    // Mode étalonnage
    QStringList args = a.arguments();
    int pos = args.indexOf("--etalonner");
    if (pos >= 0) {
        bool ok = false;
        double tension = args.value(pos + 1).toDouble(&ok);
        if (!ok) { qInfo() << "Usage : checkup --etalonner <tension mesurée au multimètre, en V>"; return 1; }
        return etalonner(checkup.teds, tension, cheminTeds);
    }

    // Checkup complet : chaque ligne s'affiche dès que son test est fini
    QObject::connect(&checkup, &Checkup::nouveauResultat, [](const QString &ligne) {
        qInfo().noquote() << ligne;
    });
    checkup.lancer();

    qInfo().noquote() << "\n" + checkup.rapport();
    return checkup.departAutorise() ? 0 : 1;
}
