#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLayout>
#include <QVBoxLayout>
#include <QDockWidget>
#include "widgetcheckup.h"   // AJOUT CHECKUP

// MODIF : l'adresse de la VOITURE (la Raspberry Pi), pas celle d'un PC.
// Sur la Pi, taper  hostname -I  pour la connaître.
const QString IP_VOITURE = "192.168.1.15";

// MODIF : les ports de la voiture (projet SAE_INFO) :
//   4321 lidar "d0;...;d359;"   1234 voiture "vitesse;angle" + START/STOP   1235 batterie "7.92"
//   (1236 TFmini : pas affiché ; 1237 checkup : géré par WidgetCheckup)
// La voiture n'accepte qu'UN client par port : START/STOP passent donc par clientVoiture
// (un 2e client sur 1234 chasserait le premier, et le START pouvait se perdre).

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    //vers pc dirigeant la voiture
    , clientLidar(IP_VOITURE, 4321)            //lidar
    , clientVoiture(IP_VOITURE, 1234)          //vitesse & angle des roues + boutons START/STOP
    , clientBatterie(IP_VOITURE, 1235)         //Batterie
{
    ui->setupUi(this);

    // MODIF : dans le .ui, ces 3 zones n'ont pas de layout : layout() renvoyait nullptr
    // et le programme plantait juste après la connexion. On leur en donne un ici.
    new QVBoxLayout(ui->widgetLidar);
    new QVBoxLayout(ui->widgetVoiture);
    new QVBoxLayout(ui->widgetBatterie);

    ui->widgetLidar->layout()->addWidget(&lidar);
    ui->widgetVoiture->layout()->addWidget(&voiture);
    ui->widgetBatterie->layout()->addWidget(&batterie);

    //connect pour recevoir les valeurs récupérées et les afficher dans les widgets
    connect(&clientLidar, &TCPclient::newDatas,
            &lidar, &WidgetLidar::processTcpDatas);
    connect(&clientVoiture, &TCPclient::newDatas,
            &voiture, &WidgetVoiture::processTcpDatas);
    connect(&clientBatterie, &TCPclient::newDatas,
            &batterie, &::WidgetBatterie::processTcpDatas);
    //BOUTONS
    connect(ui->bpOn, &QPushButton::clicked, this, &MainWindow::bpStart_clicked);
    connect(ui->bpOff, &QPushButton::clicked, this, &MainWindow::bpStop_clicked);

    // AJOUT CHECKUP : voyants des tests de la voiture + bouton test TCP (port 1237)
    QDockWidget *dock = new QDockWidget("Checkup", this);
    dock->setWidget(new WidgetCheckup(IP_VOITURE));
    addDockWidget(Qt::RightDockWidgetArea, dock);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::bpStart_clicked()
{
    clientVoiture.sendDatas("START");     // MODIF : port 1234 (avant : clientStartStop)
}

void MainWindow::bpStop_clicked()
{
    clientVoiture.sendDatas("STOP");      // MODIF : port 1234 (avant : clientStartStop)
}
