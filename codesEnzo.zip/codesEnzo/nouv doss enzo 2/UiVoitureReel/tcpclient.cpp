#include "tcpclient.h"
#include <QIODevice>
#include <QDataStream>
#include <QDebug>
#include <unistd.h>

TCPclient::TCPclient(QString _Host, int _port)
{
    // Important : il faut lier le signal du socket au slot !
    connect(&clientSocket, &QTcpSocket::readyRead, this, &TCPclient::onReadyRead);
    Host = _Host;
    port = _port;
    connectTCP();

    // MODIF : si la voiture est relancée, la connexion est coupée et n'était jamais refaite
    // (le bouton ON n'envoyait plus rien). Toutes les secondes : connexion perdue -> on la refait.
    connect(&reconnexion, &QTimer::timeout, this, [this]() {
        if (clientSocket.state() == QAbstractSocket::UnconnectedState)
            clientSocket.connectToHost(Host, port);
    });
    reconnexion.start(1000);

}

void TCPclient::connectTCP()
{
    // MODIF : on n'attend plus la voiture ici (avant : boucle infinie, la fenêtre restait
    // bloquée tant que la voiture n'était pas lancée). Si elle n'est pas là, le timer
    // "reconnexion" réessaie toutes les secondes.
    qDebug() << "Lancement de la connexion vers" << Host << ":" << port;
    clientSocket.connectToHost(Host, port);

}

void TCPclient::sendDatas(QString datas)
{
    if (clientSocket.state() != QAbstractSocket::ConnectedState) {
        qDebug() << "Impossible d'envoyer : le socket n'est pas connecté.";
        return;
        ReconnectConnectOrWait();
    }

    QByteArray block;

    QDataStream dataIn(&block, QIODevice::WriteOnly);
    dataIn.setVersion(QDataStream::Qt_5_0);   // MODIF : même version que la voiture


    // Avec les transactions, on envoie directement la donnée
    // Qt s'occupe d'encapsuler le type et la taille sous le capot.
    dataIn << datas;

    //Une fois le message encapsulé il est envoyé via le socket vers le serveur
    clientSocket.write(block);
    qDebug() << "Client :" << datas;

}

// MODIF : la voiture envoie ses messages avec QDataStream (longueur, puis caractères).
// Il faut donc les relire avec QDataStream : c'est la version qui était en commentaire.
// (La lecture "brute" avec readAll() donnait des caractères illisibles.)
void TCPclient::onReadyRead()
{
    QDataStream in(&clientSocket);
    in.setVersion(QDataStream::Qt_5_0); // Doit correspondre à la version de la voiture

    // On boucle pour traiter tous les messages si plusieurs paquets sont arrivés ensemble
    while (true) {
        in.startTransaction();

        QString messageRecu;
        in >> messageRecu; // Tente d'extraire le QString complet

        if (in.commitTransaction()) {
            // La transaction a réussi, le message est complet
            emit newDatas(messageRecu);
        } else {
            // on sort et on attend le prochain onReadyRead
            break;
        }
    }
}

void TCPclient::ReconnectConnectOrWait()
{
    while(clientSocket.state() != QAbstractSocket::ConnectedState)
    {
        clientSocket.connectToHost(Host, port);
        clientSocket.waitForConnected(3000);
        sleep(1);
    }
}