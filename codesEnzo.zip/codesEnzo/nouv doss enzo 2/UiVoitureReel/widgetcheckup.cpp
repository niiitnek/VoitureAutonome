#include "widgetcheckup.h"
#include <QLabel>
#include <QPushButton>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QDataStream>

static const int PORT_CHECKUP = 1237;      // le même que dans checkup.h de la voiture

WidgetCheckup::WidgetCheckup(const QString &ipVoiture, QWidget *parent)
    : QWidget(parent), ip(ipVoiture)
{
    // ---- l'affichage : titre, une ligne par test, bilan, puis le test TCP
    QVBoxLayout *colonne = new QVBoxLayout(this);
    colonne->addWidget(new QLabel("<b>Checkup de la voiture</b>"));

    grille = new QGridLayout;
    colonne->addLayout(grille);

    bilan = new QLabel("Voiture non connectée (port 1237)");
    colonne->addWidget(bilan);

    QHBoxLayout *ligneTcp = new QHBoxLayout;
    voyantTcp = new QLabel;
    colorer(voyantTcp, "");
    detailTcp = new QLabel("pas encore testé");
    detailTcp->setWordWrap(true);
    ligneTcp->addWidget(voyantTcp);
    ligneTcp->addWidget(new QLabel("Connexion TCP :"));
    ligneTcp->addWidget(detailTcp, 1);
    colonne->addLayout(ligneTcp);

    QPushButton *bouton = new QPushButton("Tester la connexion TCP");
    colonne->addWidget(bouton);
    colonne->addStretch();
    connect(bouton, &QPushButton::clicked, this, &WidgetCheckup::testerTcp);

    // ---- la connexion à la voiture
    connect(&socket, &QTcpSocket::connected, this, &WidgetCheckup::connecte);
    connect(&socket, &QTcpSocket::disconnected, this, &WidgetCheckup::deconnecte);
    connect(&socket, &QTcpSocket::readyRead, this, &WidgetCheckup::lire);
    connect(&reconnexion, &QTimer::timeout, this, [this]() {
        if (socket.state() == QAbstractSocket::UnconnectedState)
            socket.connectToHost(ip, PORT_CHECKUP);
    });
    reconnexion.start(1000);
    socket.connectToHost(ip, PORT_CHECKUP);

    delaiPong.setSingleShot(true);
    connect(&delaiPong, &QTimer::timeout, this, &WidgetCheckup::pasDePong);
}

WidgetCheckup::~WidgetCheckup()
{
    // À la fermeture, le socket se coupe et émettrait disconnected() : deconnecte()
    // toucherait alors des voyants déjà détruits (plantage). On le débranche d'abord.
    socket.disconnect(this);
}

// ------------------------------------------------------------------ connexion

void WidgetCheckup::connecte()
{
    bilan->setText("Connecté à la voiture : réception du checkup...");
    envoyer("CHECKUP");                    // la voiture renvoie tous ses résultats
}

void WidgetCheckup::deconnecte()
{
    // Plus de voiture : les anciens résultats ne veulent plus rien dire -> gris
    for (Ligne &l : lignes) {
        colorer(l.voyant, "");
        l.detail->setText("voiture déconnectée");
    }
    bilan->setText("Voiture non connectée (port 1237)");
    bilan->setStyleSheet("");
}

// Envoie un QString avec QDataStream (version Qt_5_0, comme la voiture)
bool WidgetCheckup::envoyer(const QString &message)
{
    QByteArray bloc;
    QDataStream sortie(&bloc, QIODevice::WriteOnly);
    sortie.setVersion(QDataStream::Qt_5_0);
    sortie << message;
    return socket.write(bloc) == bloc.size();
}

void WidgetCheckup::lire()
{
    QDataStream entree(&socket);
    entree.setVersion(QDataStream::Qt_5_0);
    while (true) {                         // plusieurs messages peuvent arriver d'un coup
        entree.startTransaction();
        QString message;
        entree >> message;
        if (!entree.commitTransaction())
            break;                         // message incomplet : on attend la suite
        traiter(message);
    }
}

// "TEST;nom;statut;detail"   "BILAN;texte"   "PONG"
void WidgetCheckup::traiter(const QString &message)
{
    if (message == "PONG") {
        if (!delaiPong.isActive())
            return;                        // PONG arrivé trop tard : déjà compté en erreur
        delaiPong.stop();
        qint64 ms = chrono.elapsed();
        if (ms <= 500) {
            colorer(voyantTcp, "OK");
            detailTcp->setText(QString("PING envoyé et reçu par la voiture, PONG reçu (%1 ms)").arg(ms));
        } else {
            colorer(voyantTcp, "ALERTE");
            detailTcp->setText(QString("PONG reçu, mais réponse lente (%1 ms)").arg(ms));
        }
    }
    else if (message.startsWith("TEST;")) {
        QString nom    = message.section(';', 1, 1);
        QString statut = message.section(';', 2, 2);
        QString detail = message.section(';', 3);
        Ligne &l = ligne(nom);
        colorer(l.voyant, statut);
        l.detail->setText(detail);
    }
    else if (message.startsWith("BILAN;")) {
        QString texte = message.section(';', 1);
        bilan->setText("<b>" + texte + "</b>");
        bilan->setStyleSheet(texte.contains("INTERDIT") ? "color: #c62828;" : "color: #2e7d32;");
    }
}

// ------------------------------------------------------------------ test TCP

void WidgetCheckup::testerTcp()
{
    if (socket.state() != QAbstractSocket::ConnectedState) {
        colorer(voyantTcp, "ERREUR");
        detailTcp->setText("pas connecté à la voiture (port 1237) : PING non envoyé");
        return;
    }
    if (!envoyer("PING")) {
        colorer(voyantTcp, "ERREUR");
        detailTcp->setText("PING non envoyé : " + socket.errorString());
        return;
    }
    colorer(voyantTcp, "");
    detailTcp->setText("PING envoyé, attente du PONG...");
    chrono.start();
    delaiPong.start(2000);
}

void WidgetCheckup::pasDePong()
{
    colorer(voyantTcp, "ERREUR");
    detailTcp->setText("PING envoyé, mais aucun PONG en 2 s : la voiture ne l'a pas reçu ou n'a pas répondu");
}

// ------------------------------------------------------------------ voyants

WidgetCheckup::Ligne &WidgetCheckup::ligne(const QString &nom)
{
    if (!lignes.contains(nom)) {
        int rang = lignes.size();
        Ligne l{new QLabel, new QLabel};
        l.detail->setWordWrap(true);
        grille->addWidget(l.voyant, rang, 0);
        grille->addWidget(new QLabel(nom + " :"), rang, 1);
        grille->addWidget(l.detail, rang, 2);
        grille->setColumnStretch(2, 1);
        lignes.insert(nom, l);
    }
    return lignes[nom];
}

// Un voyant = un petit rond de couleur
void WidgetCheckup::colorer(QLabel *voyant, const QString &statut)
{
    QString couleur = "#bdbdbd";                         // gris : pas de résultat
    if (statut == "OK")     couleur = "#34c759";         // vert
    if (statut == "ALERTE") couleur = "#ffb74d";         // orange clair
    if (statut == "ERREUR") couleur = "#e53935";         // rouge
    voyant->setFixedSize(16, 16);
    voyant->setStyleSheet("border-radius: 8px; border: 1px solid #616161; background-color: " + couleur + ";");
}
