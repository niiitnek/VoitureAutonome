#ifndef WIDGETCHECKUP_H
#define WIDGETCHECKUP_H

#include <QWidget>
#include <QTcpSocket>
#include <QTimer>
#include <QElapsedTimer>
#include <QMap>

class QLabel;
class QGridLayout;

// Panneau "Checkup" de la supervision.
//  - un voyant par test de la voiture : vert = OK, orange clair = ALERTE, rouge = ERREUR,
//    gris = pas encore de résultat
//  - le bouton "Tester la connexion TCP" : la supervision (client) envoie PING,
//    la voiture (serveur) répond PONG. PONG reçu = ça envoie et ça reçoit des deux côtés.
// Il a sa propre connexion vers la voiture, sur le port 1237 (classe Checkup de la voiture).
class WidgetCheckup : public QWidget
{
    Q_OBJECT
public:
    explicit WidgetCheckup(const QString &ipVoiture, QWidget *parent = nullptr);
    ~WidgetCheckup() override;

private slots:
    void connecte();
    void deconnecte();
    void lire();
    void testerTcp();          // bouton
    void pasDePong();          // 2 s sans réponse

private:
    struct Ligne { QLabel *voyant; QLabel *detail; };

    bool envoyer(const QString &message);
    void traiter(const QString &message);
    Ligne &ligne(const QString &nom);                       // crée la ligne si besoin
    static void colorer(QLabel *voyant, const QString &statut);

    QString ip;
    QTcpSocket socket;
    QTimer reconnexion;        // connexion perdue : nouvel essai toutes les secondes
    QTimer delaiPong;
    QElapsedTimer chrono;

    QGridLayout *grille;       // une ligne par test de la voiture
    QMap<QString, Ligne> lignes;
    QLabel *bilan;
    QLabel *voyantTcp;
    QLabel *detailTcp;
};

#endif // WIDGETCHECKUP_H
